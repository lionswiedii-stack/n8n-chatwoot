declare module 'minifaker';
