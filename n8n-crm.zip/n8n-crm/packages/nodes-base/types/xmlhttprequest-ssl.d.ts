declare module 'xmlhttprequest-ssl' {
	export const XMLHttpRequest: typeof globalThis.XMLHttpRequest;
}
