import { baseConfig } from '@n8n/stylelint-config/base';

export default baseConfig;
