module.exports = {
	content: ['./index.html', './src/**/*.{vue,js,ts}'],
	darkMode: ['selector', '[data-theme="dark"]'],
	theme: {
		extend: {},
	},
	plugins: [],
};
