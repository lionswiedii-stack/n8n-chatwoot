declare module '../../../nodes-base/dist/nodes/*';
