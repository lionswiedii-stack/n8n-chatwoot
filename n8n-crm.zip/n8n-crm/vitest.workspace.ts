export default ['packages/frontend'];
